# app.py
from flask import Flask, render_template, request, jsonify
from flask_restful import Resource, Api, reqparse
import mysql.connector

app = Flask(__name__)
api = Api(app)

# Configurações do banco de dados

db_config = {
    'host': 'seu host',
    'user': 'seu user',
    'password': 'Sua senha',
    'database': 'Nome do seu banco de dados'
}

# Função para conectar ao banco de dados MySQL
def conectar_bd():
    return mysql.connector.connect(**db_config)

def criar_tabelas():
    con = conectar_bd()
    cursor = con.cursor()


    cursor.execute('''
        CREATE TABLE IF NOT EXISTS clientes (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nome_cliente VARCHAR(50),
    email_cliente VARCHAR(50),
    telefone_cliente VARCHAR(15));
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
    id_produto INT AUTO_INCREMENT PRIMARY KEY,
    nome_produto VARCHAR(50),
    preco_produto DECIMAL(10, 2),
    quantidade_estoque INT
    );
    ''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS compras (
    id_compra INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT,
    id_produto INT,
    quantidade_comprada INT,
    data_compra DATE,
    total_compra DECIMAL(10, 2),
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente),
    FOREIGN KEY (id_produto) REFERENCES produtos(id_produto)
    );
    ''')
    cursor.execute('''
        INSERT INTO clientes(nome_cliente,email_cliente,telefone_cliente)
                   VALUES ('João Silva', 'joao@email.com',  '123456789'),
                     ('Maria Oliveira', 'maria@email.com',  '987654321'),
                     ('Carlos Santos', 'carlos@email.com',  '555123456'),
                     ('Ana Pereira', 'ana@email.com',  '987123654'),
                     ('Pedro Lima', 'pedro@email.com',  '159357852'),
                     ('Laura Souza', 'laura@email.com',  '456789123'),
                     ('Rafaela Oliveira', 'rafaela@email.com',  '98765412'),
                     ('Lucas Pereira', 'lucas@email.com',  '123987456'),
                     ('Carolina Lima', 'carolina@email.com',  '987654789'),
                     ('Gustavo Santos', 'gustavo@email.com',  '321654987'),
                     ('Isabela Oliveira', 'isabela@email.com',  '654123789'),
                     ('Bruno Silva', 'bruno@email.com',  '789456123');                   
    ''')
    cursor.execute('''
        INSERT INTO  produtos (nome_produto, preco_produto, quantidade_estoque)
                   VALUES ('Maçã', 2.50, 100),
                          ('Banana', 1.80, 150),
                          ('Laranja', 3.00, 120),
                          ('Pera', 2.00, 80),
                          ('Uva', 4.50, 200),
                          ('Morango', 5.00, 90),
                          ('Sanduíche de Frango', 7.50, 110),
                          ('Hambúrguer', 5.50, 130),
                          ('Salada de Frutas', 6.00, 100),
                          ('Batata Chips', 3.50, 70),
                          ('Cachorro-Quente', 4.00, 180),
                          ('Smoothie de Frutas', 6.50, 60);                  
    ''')
    con.commit()
    cursor.close()

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')
# Rota para exibir o formulário de adicionar produtos e processar o formulário
######################################################################################
@app.route('/adicionar_cliente', methods=['GET', 'POST'])
def adicionar_cliente():
    if request.method == 'GET':
        return render_template('formulario_adicionar_cliente.html')
    elif request.method == 'POST':
        con = conectar_bd()
        cursor = con.cursor()
    
    nome_cliente = request.form['nome_cliente']
    email_cliente = request.form['email']
    telefone_cliente = request.form['telefone']
    


    insert_query = "INSERT INTO clientes (nome_cliente, email_cliente, telefone_cliente) VALUES (%s, %s, %s)"
    dados = (nome_cliente, email_cliente, telefone_cliente)

    cursor.execute(insert_query, dados)
    con.commit()
    cursor.close()

    return jsonify({'mensagem': 'Cliente adicionado com sucesso!'})

@app.route('/modificar_cliente', methods=['GET','POST'])
def modificar_cliente():
    con = conectar_bd()
    cursor = con.cursor()

    if request.method == 'GET':
        # Inicializa 'produto' com um dicionário vazio
        cliente = {}
        return render_template('formulario_modificar_cliente.html',cliente=cliente)

    elif request.method == 'POST':
        id_cliente = int(request.form['id_cliente'])
        nome_cliente = request.form['nome_cliente']
        email_cliente = request.form['email']
        telefone_cliente = request.form['telefone']

        # Verifica se o produto existe
        cursor.execute('SELECT * FROM clientes WHERE id_cliente = %s', (id_cliente,))
        cliente = cursor.fetchone()

        if not cliente:
            return jsonify({'mensagem': 'cliente não encontrado'}), 404

        update_query = "UPDATE clientes SET nome_cliente = %s, email_cliente = %s, telefone_cliente = %s WHERE id_cliente = %s"
        dados_cliente = (nome_cliente, email_cliente, telefone_cliente, id_cliente)

    cursor.execute(update_query, dados_cliente)
    con.commit()
    cursor.close()

    return jsonify({'mensagem': 'Cliente modificado com sucesso!'})

#deletar cliente
@app.route('/deletar_cliente', methods=['GET','POST'])
def deletar_cliente():
    con = conectar_bd()
    cursor = con.cursor()

    if request.method == 'GET':
        # Inicializa 'produto' com um dicionário vazio
        cliente = {}
        return render_template('formulario_deletar_cliente.html', cliente=cliente)

    elif request.method == 'POST':
        cliente_id = int(request.form['id_cliente'])

        # Verifica se o produto existe
        cursor.execute('SELECT * FROM clientes WHERE id_cliente = %s', (cliente_id,))
        cliente = cursor.fetchone()

        if not cliente:
            return jsonify({'mensagem': 'Produto não encontrado'}), 404

        delete_query = "DELETE FROM clientes WHERE id_cliente = %s"

        cursor.execute(delete_query, (cliente_id,))
        con.commit()
        cursor.close()

        return jsonify({'mensagem': 'Produto deletado com sucesso!'})
    con = conectar_bd()
    cursor = con.cursor()

    id_cliente = int(request.form['id_cliente'])

    delete_query = "DELETE FROM clientes WHERE id_cliente = %s"
    cursor.execute(delete_query, (id_cliente,))
    con.commit()
    cursor.close()

    return jsonify({'mensagem': 'Cliente deletado com sucesso!'})

@app.route('/todos_clientes', methods=['GET'])
def todos_clientes():
    con = conectar_bd()
    cursor = con.cursor(dictionary=True)
    cursor.execute('SELECT * FROM clientes')
    clientes = cursor.fetchall()
    con.close()
    return render_template('todos_clientes.html', clientes=clientes)
    

######################################################################################

#Adicionar produtos
@app.route('/adicionar_produto', methods=['GET', 'POST'])
def adicionar_produto():
    if request.method == 'GET':
        return render_template('formulario_adicionar_produto.html')
    elif request.method == 'POST':
        con = conectar_bd()
        cursor = con.cursor()

        nome_produto = request.form['nome']
        preco_produto = float(request.form['preco'])
        quantidade_estoque = int(request.form['quantidade'])

        insert_query = "INSERT INTO produtos (nome_produto, preco_produto, quantidade_estoque) VALUES (%s, %s, %s)"
        dados = (nome_produto, preco_produto, quantidade_estoque)

        cursor.execute(insert_query, dados)
        con.commit()
        cursor.close()

        return jsonify({'mensagem': 'Produto adicionado com sucesso!'})

# Rota para exibir o formulário de modificar produtos e processar o formulário
@app.route('/modificar_produto', methods=['GET', 'POST'])
def modificar_produto():
    con = conectar_bd()
    cursor = con.cursor()

    if request.method == 'GET':
        # Inicializa 'produto' com um dicionário vazio
        produto = {}
        return render_template('formulario_modificar_produto.html', produto=produto)

    elif request.method == 'POST':
        produto_id = int(request.form['id_produto'])
        nome_produto = request.form['nome']
        preco_produto = float(request.form['preco'])
        quantidade_estoque = int(request.form['quantidade'])

        # Verifica se o produto existe
        cursor.execute('SELECT * FROM produtos WHERE id_produto = %s', (produto_id,))
        produto = cursor.fetchone()

        if not produto:
            return jsonify({'mensagem': 'Produto não encontrado'}), 404

        update_query = "UPDATE produtos SET nome_produto = %s, preco_produto = %s, quantidade_estoque = %s WHERE id_produto = %s"
        dados = (nome_produto, preco_produto, quantidade_estoque, produto_id)

        cursor.execute(update_query, dados)
        con.commit()
        cursor.close()

        return jsonify({'mensagem': 'Produto modificado com sucesso!'})

# Rota para exibir o formulário de deletar produtos e processar a exclusão
@app.route('/deletar_produto', methods=['GET', 'POST'])
def deletar_produto():
    con = conectar_bd()
    cursor = con.cursor()

    if request.method == 'GET':
        # Inicializa 'produto' com um dicionário vazio
        produto = {}
        return render_template('formulario_deletar_produto.html', produto=produto)

    elif request.method == 'POST':
        produto_id = int(request.form['id_produto'])

        # Verifica se o produto existe
        cursor.execute('SELECT * FROM produtos WHERE id_produto = %s', (produto_id,))
        produto = cursor.fetchone()

        if not produto:
            return jsonify({'mensagem': 'Produto não encontrado'}), 404

        delete_query = "DELETE FROM produtos WHERE id_produto = %s"
        cursor.execute(delete_query, (produto_id,))
        con.commit()
        cursor.close()

        return jsonify({'mensagem': 'Produto deletado com sucesso!'})


# Rota para exibir todos os produtos
@app.route('/todos_produtos', methods=['GET'])
def todos_produtos():
    con = conectar_bd()
    cursor = con.cursor(dictionary=True)
    cursor.execute('SELECT * FROM produtos')
    produtos = cursor.fetchall()
    con.close()
    return render_template('todos_produtos.html', produtos=produtos)


# Rota para exibir o formulário de adicionar produtos
@app.route('/adicionar_produto', methods=['GET'])
def exibir_formulario_adicionar_produto():
    return render_template('formulario_adicionar_produto.html')
###############################################################################################################################
#Compras
from datetime import datetime

@app.route('/comprar', methods=['GET', 'POST'])
def comprar():
    con = conectar_bd()
    cursor = con.cursor(dictionary=True)

    if request.method == 'GET':
        # Recupera a lista de produtos disponíveis
        cursor.execute('SELECT * FROM produtos WHERE quantidade_estoque > 0')
        produtos_disponiveis = cursor.fetchall()

        return render_template('formulario_compra.html', produtos_disponiveis=produtos_disponiveis)

    elif request.method == 'POST':
        id_cliente = int(request.form['id_cliente'])
        id_produto = int(request.form['id_produto'])
        quantidade_comprada = int(request.form['quantidade'])

        # Verifica se há estoque suficiente
        cursor.execute('SELECT quantidade_estoque, preco_produto FROM produtos WHERE id_produto = %s', (id_produto,))
        produto_info = cursor.fetchone()

        if not produto_info or quantidade_comprada > produto_info['quantidade_estoque']:
            return jsonify({'mensagem': 'Estoque insuficiente'}), 400

        total_compra = quantidade_comprada * produto_info['preco_produto']

        # Insere a compra na tabela de compras
        data_compra = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        insert_compra_query = "INSERT INTO compras (id_cliente, id_produto, quantidade_comprada, data_compra, total_compra) VALUES (%s, %s, %s, %s, %s)"
        compra_data = (id_cliente, id_produto, quantidade_comprada, data_compra, total_compra)
        cursor.execute(insert_compra_query, compra_data)
        con.commit()

        # Atualiza a quantidade em estoque na tabela de produtos
        nova_quantidade_estoque = produto_info['quantidade_estoque'] - quantidade_comprada
        update_estoque_query = "UPDATE produtos SET quantidade_estoque = %s WHERE id_produto = %s"
        cursor.execute(update_estoque_query, (nova_quantidade_estoque, id_produto))
        con.commit()

        con.close()

        return jsonify({'mensagem': 'Compra realizada com sucesso'})
###############################################################################################
#RELATORIOS
@app.route('/produtos_mais_comprados', methods=['GET'])
def produtos_mais_comprados():
    con = conectar_bd()
    cursor = con.cursor(dictionary=True)

    # Consulta SQL para obter os 3 produtos mais comprados
    cursor.execute('''
        SELECT produtos.id_produto, produtos.nome_produto, COUNT(*) as quantidade_vendas
        FROM compras
        JOIN produtos ON compras.id_produto = produtos.id_produto
        GROUP BY produtos.id_produto, produtos.nome_produto
        ORDER BY quantidade_vendas DESC
        LIMIT 3
    ''')

    produtos_mais_comprados = cursor.fetchall()
    con.close()

    return render_template('produtos_mais_comprados.html', produtos_mais_comprados=produtos_mais_comprados)

# Rota para exibir produtos com estoque abaixo de 100
@app.route('/produtos_baixo_estoque', methods=['GET'])
def produtos_baixo_estoque():
    con = conectar_bd()
    cursor = con.cursor(dictionary=True)

    # Consulta SQL para obter produtos com estoque abaixo de 100
    cursor.execute('''
        SELECT *
        FROM produtos
        WHERE quantidade_estoque < 100
    ''')

    produtos_baixo_estoque = cursor.fetchall()
    con.close()

    return render_template('produtos_baixo_estoque.html', produtos_baixo_estoque=produtos_baixo_estoque)

# Rota para exibir compras dos clientes
@app.route('/compras_clientes', methods=['GET'])
def compras_clientes():
    con = conectar_bd()
    cursor = con.cursor(dictionary=True)

    # Consulta SQL para obter compras dos clientes
    cursor.execute('''
        SELECT compras.id_compra, clientes.nome_cliente, produtos.nome_produto, compras.quantidade_comprada, compras.data_compra
        FROM compras
        JOIN clientes ON compras.id_cliente = clientes.id_cliente
        JOIN produtos ON compras.id_produto = produtos.id_produto
    ''')

    compras_clientes = cursor.fetchall()
    con.close()

    return render_template('compras_clientes.html', compras_clientes=compras_clientes)

############################################################################################################
# Recurso para obter todos os produtos
class ProdutosResource(Resource):
    def get(self):
        con = conectar_bd()
        cursor = con.cursor(dictionary=True)
        cursor.execute('SELECT * FROM produtos')
        produtos = cursor.fetchall()
        con.close()
        return jsonify(produtos)

api.add_resource(ProdutosResource, '/produtos')

# Inicializar o banco de dados e executar o aplicativo
if __name__ == '__main__':
    criar_tabelas()
    app.run(debug=True)
